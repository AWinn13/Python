from flask import Flask
DB = 'dojos_and_ninjas_schema'
app = Flask(__name__)
app.secret_key = "shhhhhh"
